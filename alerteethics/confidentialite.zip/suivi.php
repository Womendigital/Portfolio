<?php
session_start();
require_once 'config/database.php';

$alert_info = null;
$error = null;
$tracking_code = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tracking_code'])) {
    $tracking_code = trim($_POST['tracking_code']);
    
    if (!empty($tracking_code)) {
        try {
            $database = new Database();
            $pdo = $database->getConnection();
            
            $stmt = $pdo->prepare("
                SELECT 
                    s.id,
                    s.date_creation,
                    s.statut,
                    s.niveau_gravite,
                    s.canal_soumission,
                    s.blockchain_hash,
                    s.date_maj,
                    su.code_tracking,
                    su.dernier_acces,
                    su.nombre_acces,
                    ta.nom as type_alerte_nom
                FROM suivis su
                JOIN signalements s ON su.signalement_id = s.id
                LEFT JOIN types_alerte ta ON s.type_alerte_id = ta.id
                WHERE su.code_tracking = ?
            ");
            $stmt->execute([$tracking_code]);
            $alert_info = $stmt->fetch();
            
            if ($alert_info) {
                $update_stmt = $pdo->prepare("
                    UPDATE suivis 
                    SET dernier_acces = NOW(), nombre_acces = nombre_acces + 1 
                    WHERE code_tracking = ?
                ");
                $update_stmt->execute([$tracking_code]);
                
                $audit_stmt = $pdo->prepare("
                    INSERT INTO audit_log (signalement_id, action_type, details, ip_address, user_agent, hash_entree)
                    VALUES (?, 'acces_suivi', ?, ?, ?, SHA2(CONCAT(?, NOW(), RAND()), 256))
                ");
                $audit_stmt->execute([
                    $alert_info['id'],
                    'Consultation du suivi via code: ' . $tracking_code,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT'] ?? 'Inconnu',
                    $alert_info['id']
                ]);
                
            } else {
                $error = "Code de suivi non trouvé. Vérifiez le code et réessayez.";
            }
        } catch (Exception $e) {
            $error = "Erreur technique lors de la recherche. Veuillez réessayer.";
            error_log("Erreur suivi alerte: " . $e->getMessage());
        }
    } else {
        $error = "Veuillez saisir un code de suivi.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suivi d'Alerte - Alerte Sénégal</title>
    <meta name="description" content="Suivez l'état de traitement de votre signalement en toute sécurité et anonymat">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg: #0f1724;
            --card: #0b1220;
            --accent: #441c8a;
            --accent-light: #a78bfa;
            --muted: #9aa4b2;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --glass: rgba(255,255,255,0.04);
            --transition: all 0.3s ease;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: radial-gradient(1200px 600px at 10% 10%, rgba(124,58,237,0.08), transparent),
                       linear-gradient(180deg, #0d1422 0%, #131b2e 100%);
            color: #e6eef6;
            min-height: 100vh;
            line-height: 1.6;
        }

   
        .site-header{
            position:fixed;left:0;right:0;top:0;z-index:40;
            backdrop-filter: blur(6px);
            background:linear-gradient(180deg, rgba(15,23,36,0.9), rgba(15,23,36,0.7));
            border-bottom:1px solid rgba(255,255,255,0.03);
            transition: var(--transition);
        }
        .container{max-width:1100px;margin:0 auto;padding:0 20px}
        .nav{
            display:flex;align-items:center;justify-content:space-between;padding:14px 0;
        }
        .brand{display:flex;align-items:center;gap:12px}
        .logo{
            width:120px;
            height:60px;
            display:flex;
            align-items:center;
            justify-content:center;
            transition: var(--transition);
        }
        .logo:hover {
            transform: scale(1.05);
        }
        .nav-links{display:flex;gap:18px;align-items:center}
        .nav-links a{
            color:var(--muted);
            text-decoration:none;
            font-weight:600;
            padding: 8px 12px;
            border-radius: 8px;
            transition: var(--transition);
            position: relative;
        }
        .nav-links a:hover {
            color: white;
            background: rgba(124,58,237,0.1);
            transform: translateY(-2px);
        }
        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg,var(--accent),#06b6d4);
            transition: var(--transition);
            transform: translateX(-50%);
        }
        .nav-links a:hover::after {
            width: 80%;
        }
        .nav-links a.active {
            color: white;
            background: rgba(124,58,237,0.2);
        }
        .language-selector {
            display: flex;
            gap: 8px;
            margin-left: 15px;
            position: relative;
        }
        .lang-btn {
            background: transparent;
            border: 1px solid rgba(255,255,255,0.1);
            color: var(--muted);
            padding: 4px 10px;
            border-radius: 6px;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .lang-btn.active {
            background: rgba(124,58,237,0.2);
            color: white;
            border-color: var(--accent);
        }
        .lang-btn:hover {
            background: rgba(124,58,237,0.1);
            color: white;
        }
        .flag {
            width: 16px;
            height: 12px;
            border-radius: 2px;
            background-size: cover;
        }
        .flag-fr {
            background: linear-gradient(90deg, #002395 33%, white 33%, white 66%, #ED2939 66%);
        }
        .flag-en {
            background: linear-gradient(90deg, #012169 0%, #012169 30%, white 30%, white 34%, #C8102E 34%, #C8102E 66%, white 66%, white 70%, #012169 70%);
        }
        .menu-toggle{display:none;background:transparent;border:0;color:var(--muted);font-size:20px;cursor:pointer;transition:var(--transition)}
        .menu-toggle:hover{color:white}
        @media(max-width:880px){
            .nav-links{display:none}
            .menu-toggle{display:block}
            .language-selector { margin-left: 0; }
            .logo {
                width: 100px;
                height: 50px;
            }
        }

        /* Main Content */
        .main-content {
            padding: 120px 0 60px;
        }

        .page-header {
            text-align: center;
            padding: 40px 0;
        }

        .page-title {
            font-size: 3rem;
            margin-bottom: 1rem;
            background: linear-gradient(90deg, var(--accent), #06b6d4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .page-description {
            color: var(--muted);
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto 3rem;
        }

        .tracking-section {
            max-width: 800px;
            margin: 0 auto;
        }

        .tracking-form {
            background: var(--glass);
            padding: 2.5rem;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.06);
            margin-bottom: 2rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 2rem;
            text-align: left;
        }

        .form-label {
            display: block;
            margin-bottom: 0.8rem;
            font-weight: 600;
            color: var(--muted);
            font-size: 1.1rem;
        }

        .form-input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            color: white;
            font-size: 1.1rem;
            transition: var(--transition);
            font-family: 'Inter', sans-serif;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent-light);
            box-shadow: 0 0 0 3px rgba(124,58,237,0.1);
        }

        .btn {
            padding: 15px 30px;
            background: linear-gradient(90deg, var(--accent), #06b6d4);
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(124,58,237,0.3);
        }

        .btn-track {
            background: linear-gradient(90deg, #10b981, #06b6d4);
        }

        .alert-info {
            background: var(--glass);
            padding: 2.5rem;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.06);
            margin-bottom: 2rem;
        }

        .status-badge {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 2rem;
        }

        .status-nouveau { background: rgba(59,130,246,0.2); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
        .status-en_cours { background: rgba(245,158,11,0.2); color: #fbbf24; border: 1px solid rgba(245,158,11,0.3); }
        .status-traite { background: rgba(16,185,129,0.2); color: #34d399; border: 1px solid rgba(16,185,129,0.3); }
        .status-cloture { background: rgba(107,114,128,0.2); color: #9ca3af; border: 1px solid rgba(107,114,128,0.3); }
        .status-rejete { background: rgba(239,68,68,0.2); color: #f87171; border: 1px solid rgba(239,68,68,0.3); }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .info-item {
            background: rgba(255,255,255,0.03);
            padding: 1.5rem;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.03);
        }

        .info-label {
            font-size: 0.9rem;
            color: var(--muted);
            margin-bottom: 0.8rem;
            font-weight: 600;
        }

        .info-value {
            font-weight: 700;
            font-size: 1.2rem;
        }

        .gravite-stars {
            display: flex;
            gap: 6px;
            align-items: center;
        }

        .star {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: var(--muted);
        }

        .star.active {
            background: #f59e0b;
        }

        .alert-message {
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            border: 1px solid;
            text-align: center;
        }

        .alert-error {
            background: rgba(239,68,68,0.1);
            border-color: rgba(239,68,68,0.3);
            color: #f87171;
        }

        .alert-success {
            background: rgba(16,185,129,0.1);
            border-color: rgba(16,185,129,0.3);
            color: #34d399;
        }

        .security-notice {
            background: rgba(124,58,237,0.1);
            padding: 1.5rem;
            border-radius: 12px;
            border: 1px solid rgba(124,58,237,0.2);
            margin-top: 3rem;
            text-align: center;
            font-size: 1rem;
            color: var(--muted);
        }

        /* Footer */
        footer {
            padding: 28px 0;
            color: var(--muted);
            border-top: 1px solid rgba(255,255,255,0.03);
        }
        .footer-logo {
            height: 70px;
            margin-bottom: 10px;
        }

        .muted{color:var(--muted)}

        /* Language content */
        .lang-content {
            display: none;
        }
        .lang-content.active {
            display: block;
        }

        .logo-img {
            height: 220%;
            width: auto;
        }

        @media (max-width: 768px) {
            .page-title {
                font-size: 2.2rem;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .tracking-form, .alert-info {
                padding: 1.5rem;
            }
            
            .main-content {
                padding: 100px 0 40px;
            }
        }
    </style>
</head>
<body>
 
    <header class="site-header">
        <div class="container nav">
            <div class="brand">
                <a href="index.html">
                    <div class="logo">
                        <img src="image/logoofficielle.png" alt="Alerte Sénégal" class="logo-img" />
                    </div>
                </a>
            </div>

            <nav>
                <button class="menu-toggle" id="menuToggle">☰</button>
                <div class="nav-links" id="navLinks">
                    <a href="index.html">Accueil</a>
                    <a href="soumettre.php">Soumettre une alerte</a>
                   
                    <a href="apropos.html">À propos</a>
                    <a href="confidentialite.html">Confidentialité</a>
                    <div class="language-selector">
                        <button class="lang-btn active" data-lang="fr">
                            <div class="flag flag-fr"></div>
                            FR
                        </button>
                        <button class="lang-btn" data-lang="en">
                            <div class="flag flag-en"></div>
                            EN
                        </button>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <main class="main-content">
   
        <div class="lang-content active" data-lang="fr">
            <div class="container">
                <div class="page-header">
                    <h1 class="page-title">Suivi d'Alerte</h1>
                    <p class="page-description">
                        Consultez l'état de traitement de votre signalement en toute sécurité et confidentialité
                    </p>
                </div>

                <div class="tracking-section">
                  
                    <section class="tracking-form">
                        <h2 style="margin-bottom: 2rem; color: white; font-size: 1.8rem;">Vérifier le statut d'une alerte</h2>
                        
                        <?php if ($error): ?>
                            <div class="alert-message alert-error">
                                <strong>Erreur :</strong> <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="tracking_code" class="form-label">Code de suivi</label>
                                <input 
                                    type="text" 
                                    id="tracking_code" 
                                    name="tracking_code" 
                                    class="form-input" 
                                    placeholder="Ex: TRK-1234-ABCD"
                                    value="<?php echo htmlspecialchars($tracking_code); ?>"
                                    required
                                    pattern="[A-Z0-9\-]{8,20}"
                                    title="Format: lettres majuscules, chiffres et tirets"
                                >
                                <small style="color: var(--muted); margin-top: 0.8rem; display: block; text-align: center;">
                                    Saisissez le code de suivi unique qui vous a été fourni lors du dépôt de votre alerte.
                                </small>
                            </div>
                            
                            <button type="submit" class="btn btn-track">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12C1 12 5 4 12 4C19 4 23 12 23 12C23 12 19 20 12 20C5 20 1 12 1 12Z" stroke="currentColor" stroke-width="2"/>
                                    <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="2"/>
                                </svg>
                                Vérifier le statut
                            </button>
                        </form>
                    </section>

                  
                    <?php if ($alert_info): ?>
                        <section class="alert-info">
                            <div class="status-badge status-<?php echo htmlspecialchars($alert_info['statut']); ?>">
                                Statut: <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $alert_info['statut']))); ?>
                            </div>
                            
                            <h3 style="margin-bottom: 2rem; color: white; font-size: 1.5rem;">Détails de votre signalement</h3>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Date de création</div>
                                    <div class="info-value">
                                        <?php echo date('d/m/Y à H:i', strtotime($alert_info['date_creation'])); ?>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Type d'alerte</div>
                                    <div class="info-value">
                                        <?php echo htmlspecialchars($alert_info['type_alerte_nom'] ?? 'Non spécifié'); ?>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Niveau de gravité</div>
                                    <div class="info-value">
                                        <div class="gravite-stars">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <div class="star <?php echo $i <= $alert_info['niveau_gravite'] ? 'active' : ''; ?>"></div>
                                            <?php endfor; ?>
                                            <span style="margin-left: 10px;">(<?php echo htmlspecialchars($alert_info['niveau_gravite']); ?>/5)</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Canal de soumission</div>
                                    <div class="info-value">
                                        <?php 
                                        $canal = $alert_info['canal_soumission'];
                                        echo htmlspecialchars(ucfirst($canal));
                                        ?>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if ($alert_info['blockchain_hash']): ?>
                                <div class="info-item">
                                    <div class="info-label">Preuve blockchain</div>
                                    <div class="info-value" style="font-family: monospace; font-size: 0.9rem; word-break: break-all;">
                                        <?php echo substr(htmlspecialchars($alert_info['blockchain_hash']), 0, 20); ?>...
                                        <small style="color: var(--muted); display: block; margin-top: 5px;">
                                            Horodatage certifié sur la blockchain
                                        </small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </section>
                        
                        <div class="alert-message alert-success">
                            <strong style="font-size: 1.1rem;">Votre signalement est bien enregistré.</strong> 
                            <p style="margin-top: 10px; margin-bottom: 0;">
                                <?php 
                                switch($alert_info['statut']) {
                                    case 'nouveau':
                                        echo "Il sera examiné prochainement par notre équipe.";
                                        break;
                                    case 'en_cours':
                                        echo "Votre signalement est actuellement en cours de traitement.";
                                        break;
                                    case 'traite':
                                        echo "Votre signalement a été traité avec succès.";
                                        break;
                                    case 'cloture':
                                        echo "Ce signalement a été clôturé.";
                                        break;
                                    case 'rejete':
                                        echo "Ce signalement a été rejeté après analyse.";
                                        break;
                                    default:
                                        echo "Statut en cours de traitement.";
                                }
                                ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <div class="security-notice">
                        <strong style="display: block; margin-bottom: 8px; font-size: 1.1rem;">Sécurité garantie</strong>
                        Votre consultation est anonyme et sécurisée. Aucune information personnelle n'est stockée ou tracée. 
                        Tous les accès sont journalisés pour assurer la traçabilité.
                    </div>
                </div>
            </div>
        </div>

       
        <div class="lang-content" data-lang="en">
            <div class="container">
                <div class="page-header">
                    <h1 class="page-title">Alert Tracking</h1>
                    <p class="page-description">
                        Check the status of your report securely and confidentially
                    </p>
                </div>

                <div class="tracking-section">
                 
                    <section class="tracking-form">
                        <h2 style="margin-bottom: 2rem; color: white; font-size: 1.8rem;">Check Alert Status</h2>
                        
                        <?php if ($error): ?>
                            <div class="alert-message alert-error">
                                <strong>Error:</strong> <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="tracking_code" class="form-label">Tracking Code</label>
                                <input 
                                    type="text" 
                                    id="tracking_code_en" 
                                    name="tracking_code" 
                                    class="form-input" 
                                    placeholder="Ex: TRK-1234-ABCD"
                                    value="<?php echo htmlspecialchars($tracking_code); ?>"
                                    required
                                    pattern="[A-Z0-9\-]{8,20}"
                                    title="Format: uppercase letters, numbers and hyphens"
                                >
                                <small style="color: var(--muted); margin-top: 0.8rem; display: block; text-align: center;">
                                    Enter the unique tracking code provided when you submitted your alert.
                                </small>
                            </div>
                            
                            <button type="submit" class="btn btn-track">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12C1 12 5 4 12 4C19 4 23 12 23 12C23 12 19 20 12 20C5 20 1 12 1 12Z" stroke="currentColor" stroke-width="2"/>
                                    <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="2"/>
                                </svg>
                                Check Status
                            </button>
                        </form>
                    </section>

                  
                    <?php if ($alert_info): ?>
                        <section class="alert-info">
                            <div class="status-badge status-<?php echo htmlspecialchars($alert_info['statut']); ?>">
                                Status: <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $alert_info['statut']))); ?>
                            </div>
                            
                            <h3 style="margin-bottom: 2rem; color: white; font-size: 1.5rem;">Your Report Details</h3>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Creation Date</div>
                                    <div class="info-value">
                                        <?php echo date('m/d/Y at H:i', strtotime($alert_info['date_creation'])); ?>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Alert Type</div>
                                    <div class="info-value">
                                        <?php echo htmlspecialchars($alert_info['type_alerte_nom'] ?? 'Not specified'); ?>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Severity Level</div>
                                    <div class="info-value">
                                        <div class="gravite-stars">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <div class="star <?php echo $i <= $alert_info['niveau_gravite'] ? 'active' : ''; ?>"></div>
                                            <?php endfor; ?>
                                            <span style="margin-left: 10px;">(<?php echo htmlspecialchars($alert_info['niveau_gravite']); ?>/5)</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Submission Channel</div>
                                    <div class="info-value">
                                        <?php 
                                        $canal = $alert_info['canal_soumission'];
                                        echo htmlspecialchars(ucfirst($canal));
                                        ?>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if ($alert_info['blockchain_hash']): ?>
                                <div class="info-item">
                                    <div class="info-label">Blockchain Proof</div>
                                    <div class="info-value" style="font-family: monospace; font-size: 0.9rem; word-break: break-all;">
                                        <?php echo substr(htmlspecialchars($alert_info['blockchain_hash']), 0, 20); ?>...
                                        <small style="color: var(--muted); display: block; margin-top: 5px;">
                                            Timestamp certified on blockchain
                                        </small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </section>
                        
                        <div class="alert-message alert-success">
                            <strong style="font-size: 1.1rem;">Your report has been successfully registered.</strong> 
                            <p style="margin-top: 10px; margin-bottom: 0;">
                                <?php 
                                switch($alert_info['statut']) {
                                    case 'nouveau':
                                        echo "It will be reviewed shortly by our team.";
                                        break;
                                    case 'en_cours':
                                        echo "Your report is currently being processed.";
                                        break;
                                    case 'traite':
                                        echo "Your report has been successfully processed.";
                                        break;
                                    case 'cloture':
                                        echo "This report has been closed.";
                                        break;
                                    case 'rejete':
                                        echo "This report has been rejected after analysis.";
                                        break;
                                    default:
                                        echo "Status being processed.";
                                }
                                ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <div class="security-notice">
                        <strong style="display: block; margin-bottom: 8px; font-size: 1.1rem;">Security Guaranteed</strong>
                        Your consultation is anonymous and secure. No personal information is stored or tracked. 
                        All accesses are logged to ensure traceability.
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="container" style="display:flex;justify-content:space-between;align-items:center">
            <div>
                <img src="image/logoofficielle.png" alt="Alerte Sénégal" class="footer-logo" />
                <div class="muted" style="font-size:13px">© 2025 Alerte Sénégal - Pour la transparence et la bonne gouvernance</div>
            </div>
            <div class="muted">Renforcement de la transparence et de la bonne gouvernance</div>
        </div>
    </footer>

    <script>
        
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        
        menuToggle.addEventListener('click', () => {
            if (navLinks.style.display === 'flex') {
                navLinks.style.display = 'none';
            } else {
                navLinks.style.display = 'flex';
                navLinks.style.flexDirection = 'column';
                navLinks.style.gap = '12px';
                navLinks.style.alignItems = 'flex-end';
                navLinks.style.padding = '12px';
                navLinks.style.background = 'linear-gradient(180deg, rgba(7,10,18,0.95), rgba(7,10,18,0.98))';
                navLinks.style.borderRadius = '12px';
                navLinks.style.position = 'absolute';
                navLinks.style.right = '20px';
                navLinks.style.top = '64px';
            }
        });

      
        const langButtons = document.querySelectorAll('.lang-btn');
        const langContents = document.querySelectorAll('.lang-content');
        
        langButtons.forEach(button => {
            button.addEventListener('click', () => {
                const lang = button.getAttribute('data-lang');
                
              
                langButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                
                langContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.getAttribute('data-lang') === lang) {
                        content.classList.add('active');
                    }
                });
            });
        });

 
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            
            forms.forEach(form => {
                const input = form.querySelector('input[type="text"]');
                
                form.addEventListener('submit', function(e) {
                    const code = input.value.trim();
                    
                    if (!code) {
                        e.preventDefault();
                        alert('Veuillez saisir un code de suivi. / Please enter a tracking code.');
                        input.focus();
                        return;
                    }
                    
                    if (!/^[A-Z0-9\-]{8,20}$/.test(code)) {
                        e.preventDefault();
                        alert('Le code de suivi doit contenir uniquement des lettres majuscules, chiffres et tirets (8-20 caractères). / Tracking code must contain only uppercase letters, numbers and hyphens (8-20 characters).');
                        input.focus();
                        return;
                    }
                });
                
                input.addEventListener('input', function() {
                    this.value = this.value.toUpperCase();
                });
            });
        });

    
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.nav') && navLinks.style.display === 'flex') {
                navLinks.style.display = 'none';
            }
        });
    </script>
</body>
</html>