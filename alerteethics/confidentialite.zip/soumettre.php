<?php
// Démarrage de session et connexion à la base de données
session_start();


require_once 'config/database.php';

// Fonction pour chiffrer les données
function encryptData($data, $key) {
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}

// Fonction pour générer un code de suivi
function generateTrackingCode() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = 'AS-';
    for ($i = 0; $i < 8; $i++) {
        $code .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $code;
}

// Fonction pour obtenir l'ID du type d'alerte
function getTypeAlerteId($pdo, $type) {
    $map = [
        'corruption' => 1,
        'harcelement' => 2,
        'harassment' => 2,
        'discrimination' => 5,
        'fraude' => 4,
        'fraud' => 4,
        'detournement' => 1,
        'embezzlement' => 1,
        'conflit' => 6,
        'conflict' => 6,
        'autre' => 9,
        'other' => 9
    ];
    
    return $map[$type] ?? 9;
}

// Fonction pour déterminer la gravité
function determineGravite($type) {
    $gravites = [
        'corruption' => 4,
        'harcelement' => 3,
        'harassment' => 3,
        'discrimination' => 3,
        'fraude' => 4,
        'fraud' => 4,
        'detournement' => 5,
        'embezzlement' => 5,
        'conflit' => 3,
        'conflict' => 3,
        'autre' => 2,
        'other' => 2
    ];
    
    return $gravites[$type] ?? 2;
}

// Traitement de la soumission du formulaire
$successMessage = '';
$trackingCode = '';
$submitted = false;
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Récupération des données du formulaire
        $alertType = $_POST['alertType'] ?? '';
        $institution = $_POST['institution'] ?? '';
        $location = $_POST['location'] ?? '';
        $description = $_POST['description'] ?? '';
        $additionalInfo = $_POST['additionalInfo'] ?? '';
        $lang = $_POST['lang'] ?? 'fr';
        
        // Validation des champs requis
        if (empty($alertType) || empty($institution) || empty($location) || empty($description)) {
            throw new Exception($lang === 'fr' ? 'Veuillez remplir tous les champs obligatoires' : 'Please fill all required fields');
        }
        
        // Préparation des données pour le chiffrement
        $alertData = [
            'type' => $alertType,
            'institution' => $institution,
            'location' => $location,
            'description' => $description,
            'additionalInfo' => $additionalInfo,
            'timestamp' => date('Y-m-d H:i:s'),
            'lang' => $lang
        ];
        
        // Génération des clés de chiffrement
        $encryptionKey = bin2hex(random_bytes(32));
        $iv = bin2hex(random_bytes(16));
        
        // Chiffrement des données
        $contenuChiffre = encryptData(json_encode($alertData), $encryptionKey);
        $hashContenu = hash('sha256', $contenuChiffre);
        
        // Obtention de l'ID du type d'alerte et de la gravité
        $typeAlerteId = getTypeAlerteId($pdo, $alertType);
        $niveauGravite = determineGravite($alertType);
        
        // Insertion dans la table signalements
        $stmt = $pdo->prepare("
            INSERT INTO signalements 
            (contenu_chiffre, statut, type_alerte_id, niveau_gravite, canal_soumission, iv_chiffrement, hash_contenu) 
            VALUES (?, 'nouveau', ?, ?, 'web', ?, ?)
        ");
        
        $stmt->execute([
            $contenuChiffre,
            $typeAlerteId,
            $niveauGravite,
            $iv,
            $hashContenu
        ]);
        
        $signalementId = $pdo->lastInsertId();
        
        // Génération du code de suivi
        $trackingCode = generateTrackingCode();
        
        // Hash de la clé de déchiffrement
        $cleHash = hash('sha256', $encryptionKey);
        
        // Insertion dans la table suivis
        $stmt = $pdo->prepare("
            INSERT INTO suivis 
            (code_tracking, signalement_id, cle_dechiffrement_hash) 
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([
            $trackingCode,
            $signalementId,
            $cleHash
        ]);
        
        // Gestion des fichiers uploadés
        if (!empty($_FILES['evidence']['name'][0])) {
            $fileCount = count($_FILES['evidence']['name']);
            
            for ($i = 0; $i < $fileCount; $i++) {
                if ($_FILES['evidence']['error'][$i] === UPLOAD_ERR_OK) {
                    $fileName = $_FILES['evidence']['name'][$i];
                    $fileTmpName = $_FILES['evidence']['tmp_name'][$i];
                    $fileSize = $_FILES['evidence']['size'][$i];
                    $fileType = $_FILES['evidence']['type'][$i];
                    
                    // Validation de la taille du fichier
                    if ($fileSize > 10 * 1024 * 1024) {
                        continue; // Fichier trop volumineux, on ignore
                    }
                    
                    // Validation du type de fichier
                    $allowedTypes = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'mp4', 'mov', 'avi'];
                    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    
                    if (!in_array($fileExtension, $allowedTypes)) {
                        continue; // Type de fichier non autorisé, on ignore
                    }
                    
                    // Lecture et chiffrement du fichier
                    $fileContent = file_get_contents($fileTmpName);
                    $fileIv = bin2hex(random_bytes(16));
                    $encryptedFileName = encryptData($fileName, $encryptionKey);
                    $encryptedContent = encryptData($fileContent, $encryptionKey);
                    $fileHash = hash('sha256', $encryptedContent);
                    
                    // Insertion dans la table pieces_jointes
                    $stmt = $pdo->prepare("
                        INSERT INTO pieces_jointes 
                        (signalement_id, nom_fichier_chiffre, contenu_chiffre, type_mime, taille_originale, hash_fichier, iv_chiffrement) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    $stmt->execute([
                        $signalementId,
                        $encryptedFileName,
                        $encryptedContent,
                        $fileType,
                        $fileSize,
                        $fileHash,
                        $fileIv
                    ]);
                }
            }
        }
        
        // Journalisation dans audit_log
        $stmt = $pdo->prepare("
            INSERT INTO audit_log 
            (signalement_id, action_type, details, ip_address, user_agent, hash_entree) 
            VALUES (?, 'creation', ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $signalementId,
            'Nouveau signalement créé via le formulaire web',
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT'],
            hash('sha256', $signalementId . time() . rand())
        ]);
        
        $submitted = true;
        $successMessage = $lang === 'fr' 
            ? 'Votre alerte a été soumise avec succès! Votre code de suivi est: ' 
            : 'Your alert has been submitted successfully! Your tracking code is: ';
            
    } catch (Exception $e) {
        $errorMessage = $e->getMessage();
    }
}

// Déterminer la langue active
$currentLang = $_POST['lang'] ?? 'fr';
?>
<!doctype html>
<html lang="<?php echo $currentLang; ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title><?php echo $currentLang === 'fr' ? 'Soumettre une Alerte - Alerte Sénégal' : 'Submit Alert - Alert Senegal'; ?></title>
  <meta name="description" content="<?php echo $currentLang === 'fr' ? 'Soumettez votre alerte de manière sécurisée et anonyme' : 'Submit your alert securely and anonymously'; ?>" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0f1724;
      --card: #1a2332;
      --accent: #441c8a;
      --accent-light: #6d28d9;
      --accent-secondary: #2c5aa0;
      --accent-secondary-light: #3b82f6;
      --light-blue: #e0f2fe;
      --light-purple: #f3e8ff;
      --light-green: #dcfce7;
      --light-yellow: #fef9c3;
      --light-orange: #ffedd5;
      --danger: #dc2626;
      --success: #059669;
      --warning: #d97706;
      --muted: #94a3b8;
      --text: #e2e8f0;
      --transition: all 0.3s ease;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    html, body {
      height: 100%;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }
    
    .site-header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      background: rgba(15, 23, 36, 0.95);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      padding: 1rem 0;
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    
    .nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .brand {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    
    .logo {
      width: 100px;
      height: 100px;
      transition: var(--transition);
    }
    
    .logo:hover {
      transform: scale(1.05);
    }
    
    .brand-text {
      display: flex;
      flex-direction: column;
    }
    
    .brand-name {
      font-size: 1.25rem;
      font-weight: 700;
      color: white;
    }
    
    .brand-subtitle {
      font-size: 0.75rem;
      color: var(--muted);
    }
    
    .nav-links {
      display: flex;
      gap: 2rem;
      align-items: center;
    }
    
    .nav-links a {
      color: var(--muted);
      text-decoration: none;
      font-weight: 500;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      transition: var(--transition);
    }
    
    .nav-links a:hover {
      color: white;
      background: rgba(68, 28, 138, 0.1);
    }

    .language-selector {
      display: flex;
      gap: 0.5rem;
      margin-left: 1rem;
    }
    
    .lang-btn {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: var(--muted);
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      cursor: pointer;
      transition: var(--transition);
      font-size: 0.75rem;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }
    
    .lang-btn.active {
      background: rgba(68, 28, 138, 0.2);
      color: white;
      border-color: var(--accent);
    }
    
    .lang-btn:hover {
      background: rgba(68, 28, 138, 0.1);
      color: white;
    }
    
    .flag {
      width: 16px;
      height: 12px;
      border-radius: 2px;
      background-size: cover;
    }
    
    .flag-fr {
      background: linear-gradient(90deg, #002395 33%, white 33%, white 66%, #ED2939 66%);
    }
    
    .flag-en {
      background: linear-gradient(90deg, #012169 0%, #012169 30%, white 30%, white 34%, #C8102E 34%, #C8102E 66%, white 66%, white 70%, #012169 70%);
    }
    
    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--muted);
      font-size: 1.5rem;
      cursor: pointer;
    }
    
    .alert-container {
      padding-top: 120px;
      padding-bottom: 4rem;
      max-width: 800px;
      margin: 0 auto;
    }
    
    .alert-header {
      text-align: center;
      margin-bottom: 3rem;
      padding: 2rem 0;
      background: linear-gradient(135deg, rgba(68, 28, 138, 0.1), rgba(59, 130, 246, 0.1));
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .alert-title {
      font-size: 2.5rem;
      font-weight: 700;
      background: linear-gradient(135deg, var(--accent), var(--accent-light));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 1rem;
    }
    
    .alert-subtitle {
      font-size: 1.1rem;
      color: var(--muted);
      max-width: 600px;
      margin: 0 auto;
    }
    
    .security-banner {
      background: rgba(220, 38, 38, 0.1);
      border: 1px solid rgba(220, 38, 38, 0.3);
      padding: 1.5rem;
      border-radius: 12px;
      margin-bottom: 2rem;
      display: flex;
      align-items: flex-start;
      gap: 1rem;
    }
    
    .security-icon {
      color: var(--danger);
      font-size: 1.5rem;
      flex-shrink: 0;
    }
    
    .security-text {
      color: var(--muted);
    }
    
    .security-text strong {
      color: white;
    }
    
    .alert-form {
      background: var(--card);
      padding: 2.5rem;
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .form-group {
      margin-bottom: 2rem;
    }
    
    .form-label {
      display: block;
      color: white;
      font-weight: 600;
      margin-bottom: 0.75rem;
      font-size: 1rem;
    }
    
    .form-required {
      color: var(--danger);
    }
    
    .form-input,
    .form-select,
    .form-textarea {
      width: 100%;
      padding: 1rem;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      color: var(--text);
      font-size: 1rem;
      transition: var(--transition);
    }
    
    .form-input:focus,
    .form-select:focus,
    .form-textarea:focus {
      outline: none;
      border-color: var(--accent);
      background: rgba(255, 255, 255, 0.08);
    }
    
    .form-select {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%236d28d9' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 1rem center;
      background-size: 16px;
      appearance: none;
      padding-right: 3rem;
    }
    
    .form-textarea {
      resize: vertical;
      min-height: 150px;
      font-family: inherit;
    }
    
    .file-upload {
      border: 2px dashed rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      padding: 2rem;
      text-align: center;
      cursor: pointer;
      transition: var(--transition);
      background: rgba(59, 130, 246, 0.05);
    }
    
    .file-upload:hover {
      border-color: var(--accent);
      background: rgba(68, 28, 138, 0.1);
    }
    
    .file-input {
      display: none;
    }
    
    .file-list {
      margin-top: 1rem;
    }
    
    .file-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.75rem;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 6px;
      margin-bottom: 0.5rem;
    }
    
    .file-remove {
      color: var(--danger);
      background: none;
      border: none;
      cursor: pointer;
      padding: 0.25rem;
      border-radius: 4px;
      transition: var(--transition);
    }
    
    .file-remove:hover {
      background: rgba(220, 38, 38, 0.1);
    }
    
    .checkbox-group {
      display: flex;
      align-items: flex-start;
      gap: 1rem;
      margin-bottom: 1rem;
      padding: 1.5rem;
      background: rgba(220, 252, 231, 0.05);
      border-radius: 8px;
      border: 1px solid rgba(5, 150, 105, 0.2);
    }
    
    .form-checkbox {
      width: 20px;
      height: 20px;
      margin-top: 0.25rem;
      flex-shrink: 0;
    }
    
    .checkbox-label {
      color: var(--muted);
      font-size: 0.9rem;
      line-height: 1.4;
    }
    
    .checkbox-label a {
      color: var(--accent-light);
      text-decoration: none;
    }
    
    .checkbox-label a:hover {
      text-decoration: underline;
    }
    
    .submit-btn {
      width: 100%;
      padding: 1.25rem;
      background: linear-gradient(135deg, var(--accent), var(--accent-light));
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: var(--transition);
      margin-top: 2rem;
    }
    
    .submit-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(68, 28, 138, 0.3);
    }
    
    .submit-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }
    
    .success-message {
      background: rgba(5, 150, 105, 0.1);
      border: 1px solid rgba(5, 150, 105, 0.3);
      padding: 2rem;
      border-radius: 12px;
      text-align: center;
      margin-top: 2rem;
    }
    
    .tracking-code {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--success);
      margin: 1rem 0;
      font-family: monospace;
      letter-spacing: 2px;
    }
    
    .site-footer {
      background: var(--card);
      padding: 3rem 0 2rem;
      border-top: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .footer-content {
      display: grid;
      grid-template-columns: 1fr 2fr;
      gap: 3rem;
      align-items: start;
    }
    
    .footer-brand {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    
    .footer-logo {
      width: 180px;
      height: auto;
    }
    
    .footer-links {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
    }
    
    .footer-column h4 {
      color: white;
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 1rem;
    }
    
    .footer-column a {
      color: var(--muted);
      text-decoration: none;
      display: block;
      margin-bottom: 0.5rem;
      transition: var(--transition);
    }
    
    .footer-column a:hover {
      color: white;
    }
    
    .footer-bottom {
      margin-top: 3rem;
      padding-top: 2rem;
      border-top: 1px solid rgba(255, 255, 255, 0.05);
      text-align: center;
      color: var(--muted);
      font-size: 0.875rem;
    }
    
    .color-accent {
      color: var(--accent-light);
    }
    
    .color-secondary {
      color: var(--accent-secondary-light);
    }
    
    .color-success {
      color: var(--success);
    }
    
    .color-warning {
      color: var(--warning);
    }
    
    .color-danger {
      color: var(--danger);
    }
    
    .bg-gradient {
      background: linear-gradient(135deg, var(--accent), var(--accent-light));
    }
    
    .bg-gradient-secondary {
      background: linear-gradient(135deg, var(--accent-secondary), var(--accent-secondary-light));
    }
    
    .form-section {
      margin-bottom: 2.5rem;
      padding-bottom: 2rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .form-section-title {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 1.5rem;
      color: white;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 1rem;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
    }
    
    .form-section-title::before {
      content: '';
      display: block;
      width: 4px;
      height: 20px;
      background: var(--accent-light);
      border-radius: 2px;
    }
    
    .color-highlight {
      background: rgba(255, 255, 255, 0.05);
      padding: 1.5rem;
      border-radius: 8px;
      margin-bottom: 1.5rem;
    }
    
    .color-highlight.blue {
      background: rgba(59, 130, 246, 0.1);
      border-left: 4px solid var(--accent-secondary-light);
    }
    
    .color-highlight.purple {
      background: rgba(107, 33, 168, 0.1);
      border-left: 4px solid var(--accent);
    }
    
    .color-highlight.green {
      background: rgba(5, 150, 105, 0.1);
      border-left: 4px solid var(--success);
    }
    
    .error-message {
      background: rgba(220, 38, 38, 0.1);
      border: 1px solid rgba(220, 38, 38, 0.3);
      padding: 1rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      color: var(--danger);
    }
    
    @media (max-width: 768px) {
      .container {
        padding: 0 1rem;
      }
      
      .menu-toggle {
        display: block;
      }
      
      .nav-links {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: var(--card);
        flex-direction: column;
        padding: 1rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        gap: 1rem;
      }
      
      .nav-links.active {
        display: flex;
      }
      
      .language-selector {
        margin-left: 0;
        justify-content: center;
      }
      
      .alert-title {
        font-size: 2rem;
      }
      
      .alert-form {
        padding: 1.5rem;
      }
      
      .footer-content {
        grid-template-columns: 1fr;
        gap: 2rem;
      }
      
      .footer-links {
        grid-template-columns: 1fr;
        gap: 1.5rem;
      }
      
      .footer-logo {
        width: 100px;
      }
    }
  </style>
</head>
<body>
  <header class="site-header">
    <div class="container">
      <nav class="nav">
        <div class="brand">
          <img src="image/logoofficielle.png" alt="Alerte Sénégal" class="logo">
          <div class="brand-text">
            <div class="brand-name">Alerte Sénégal</div>
            <div class="brand-subtitle">Signalement Éthique Sécurisé</div>
          </div>
        </div>
        
        <button class="menu-toggle" id="menuToggle">☰</button>
        
        <div class="nav-links" id="navLinks">
          <a href="index.html">Accueil</a>
          <a href="suivi.php">Suivre une alerte</a>
          <a href="apropos.html">À propos</a>
          <a href="confidentialite.html">Confidentialité</a>
          <div class="language-selector">
            <button type="button" class="lang-btn <?php echo $currentLang === 'fr' ? 'active' : ''; ?>" data-lang="fr">
              <div class="flag flag-fr"></div>
              FR
            </button>
            <button type="button" class="lang-btn <?php echo $currentLang === 'en' ? 'active' : ''; ?>" data-lang="en">
              <div class="flag flag-en"></div>
              EN
            </button>
          </div>
        </div>
      </nav>
    </div>
  </header>

  <main class="container alert-container">
    <?php if ($submitted): ?>
      <!-- Message de succès -->
      <div class="success-message">
        <div style="font-size: 3rem; margin-bottom: 1rem;">✅</div>
        <h3 style="color: white; margin-bottom: 1rem;">
          <?php echo $currentLang === 'fr' ? 'Alerte soumise avec succès' : 'Alert Submitted Successfully'; ?>
        </h3>
        <p style="color: var(--muted); margin-bottom: 1.5rem;">
          <?php echo $successMessage; ?>
        </p>
        <div class="tracking-code"><?php echo $trackingCode; ?></div>
        <p style="color: var(--muted); font-size: 0.9rem;">
          <?php echo $currentLang === 'fr' 
            ? 'Utilisez ce code pour suivre l\'avancement de votre alerte' 
            : 'Use this code to track the progress of your alert'; ?>
        </p>
        <a href="suivi.php?code=<?php echo $trackingCode; ?>" style="display: inline-block; margin-top: 1rem; padding: 0.5rem 1rem; background: var(--accent); color: white; text-decoration: none; border-radius: 6px;">
          <?php echo $currentLang === 'fr' ? 'Suivre mon alerte' : 'Track my alert'; ?>
        </a>
      </div>
    <?php else: ?>
      <!-- Formulaire de soumission -->
      <?php if (!empty($errorMessage)): ?>
        <div class="error-message">
          <?php echo $errorMessage; ?>
        </div>
      <?php endif; ?>

      <div class="alert-header">
        <h1 class="alert-title">
          <?php echo $currentLang === 'fr' ? 'Soumettre une Alerte' : 'Submit an Alert'; ?>
        </h1>
        <p class="alert-subtitle">
          <?php echo $currentLang === 'fr' 
            ? 'Signalez de manière sécurisée et anonyme tout cas de corruption, harcèlement ou manquement éthique' 
            : 'Securely and anonymously report any case of corruption, harassment or ethical misconduct'; ?>
        </p>
      </div>

      <div class="security-banner">
        <div class="security-icon">🛡️</div>
        <div class="security-text">
          <strong>
            <?php echo $currentLang === 'fr' ? 'Sécurité maximale garantie' : 'Maximum security guaranteed'; ?>
          </strong> - 
          <?php echo $currentLang === 'fr' 
            ? 'Votre signalement est chiffré de bout en bout et protégé par blockchain. Aucune information personnelle n\'est collectée.' 
            : 'Your report is end-to-end encrypted and protected by blockchain. No personal information is collected.'; ?>
        </div>
      </div>

      <div class="color-highlight blue">
        <h3>💡 <?php echo $currentLang === 'fr' ? 'Comment rédiger un bon signalement' : 'How to write a good report'; ?></h3>
        <p>
          <?php echo $currentLang === 'fr' 
            ? 'Pour que votre alerte soit traitée efficacement, veuillez fournir des informations précises : dates, lieux, personnes impliquées, montants concernés et toute preuve disponible.' 
            : 'For your alert to be processed effectively, please provide accurate information: dates, locations, people involved, amounts concerned and any available evidence.'; ?>
        </p>
      </div>

      <form method="POST" enctype="multipart/form-data" class="alert-form" id="alertForm">
        <input type="hidden" name="lang" value="<?php echo $currentLang; ?>">
        
        <div class="form-section">
          <h3 class="form-section-title">
            <?php echo $currentLang === 'fr' ? 'Informations principales' : 'Main Information'; ?>
          </h3>
          
          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Type d\'alerte' : 'Alert Type'; ?> <span class="form-required">*</span>
            </label>
            <select class="form-select" name="alertType" required>
              <option value=""><?php echo $currentLang === 'fr' ? 'Sélectionnez un type' : 'Select a type'; ?></option>
              <option value="corruption"><?php echo $currentLang === 'fr' ? 'Corruption' : 'Corruption'; ?></option>
              <option value="harcelement"><?php echo $currentLang === 'fr' ? 'Harcèlement' : 'Harassment'; ?></option>
              <option value="discrimination"><?php echo $currentLang === 'fr' ? 'Discrimination' : 'Discrimination'; ?></option>
              <option value="fraude"><?php echo $currentLang === 'fr' ? 'Fraude' : 'Fraud'; ?></option>
              <option value="detournement"><?php echo $currentLang === 'fr' ? 'Détournement de fonds' : 'Embezzlement'; ?></option>
              <option value="conflit"><?php echo $currentLang === 'fr' ? 'Conflit d\'intérêts' : 'Conflict of interest'; ?></option>
              <option value="autre"><?php echo $currentLang === 'fr' ? 'Autre manquement éthique' : 'Other ethical misconduct'; ?></option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Institution/organisme concerné' : 'Concerned institution/organization'; ?> <span class="form-required">*</span>
            </label>
            <input type="text" class="form-input" name="institution" required 
                   placeholder="<?php echo $currentLang === 'fr' 
                     ? 'Nom de l\'institution, entreprise ou organisation' 
                     : 'Name of institution, company or organization'; ?>">
          </div>

          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Localisation' : 'Location'; ?> <span class="form-required">*</span>
            </label>
            <select class="form-select" name="location" required>
              <option value=""><?php echo $currentLang === 'fr' ? 'Sélectionnez une région' : 'Select a region'; ?></option>
              <option value="dakar">Dakar</option>
              <option value="thies">Thiès</option>
              <option value="diourbel">Diourbel</option>
              <option value="fatick">Fatick</option>
              <option value="kaffrine">Kaffrine</option>
              <option value="kaolack">Kaolack</option>
              <option value="kedougou">Kédougou</option>
              <option value="kolda">Kolda</option>
              <option value="louga">Louga</option>
              <option value="matam">Matam</option>
              <option value="saint-louis">Saint-Louis</option>
              <option value="sedhiou">Sédhiou</option>
              <option value="tambacounda">Tambacounda</option>
              <option value="ziguinchor">Ziguinchor</option>
            </select>
          </div>
        </div>

        <div class="form-section">
          <h3 class="form-section-title">
            <?php echo $currentLang === 'fr' ? 'Détails de l\'alerte' : 'Alert Details'; ?>
          </h3>
          
          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Description détaillée' : 'Detailed Description'; ?> <span class="form-required">*</span>
            </label>
            <textarea class="form-textarea" name="description" required 
                      placeholder="<?php echo $currentLang === 'fr' 
                        ? 'Décrivez la situation de manière précise, avec dates, lieux, personnes impliquées, montants concernés...' 
                        : 'Describe the situation precisely, with dates, locations, people involved, amounts concerned...'; ?>"></textarea>
          </div>

          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Preuves (optionnel)' : 'Evidence (optional)'; ?>
            </label>
            <div class="file-upload" id="fileUpload">
              <div>📎 <?php echo $currentLang === 'fr' ? 'Cliquez pour ajouter des documents, photos ou vidéos' : 'Click to add documents, photos or videos'; ?></div>
              <div style="font-size: 0.875rem; color: var(--muted); margin-top: 0.5rem;">
                <?php echo $currentLang === 'fr' 
                  ? 'Formats acceptés : PDF, JPG, PNG, MP4, DOCX (max 10MB par fichier)' 
                  : 'Accepted formats: PDF, JPG, PNG, MP4, DOCX (max 10MB per file)'; ?>
              </div>
            </div>
            <input type="file" class="file-input" id="fileInput" name="evidence[]" multiple 
                   accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.mp4,.mov,.avi">
            <div class="file-list" id="fileList"></div>
          </div>

          <div class="form-group">
            <label class="form-label">
              <?php echo $currentLang === 'fr' ? 'Informations supplémentaires' : 'Additional Information'; ?>
            </label>
            <textarea class="form-textarea" name="additionalInfo" 
                      placeholder="<?php echo $currentLang === 'fr' 
                        ? 'Autres informations utiles, témoins potentiels, contexte...' 
                        : 'Other useful information, potential witnesses, context...'; ?>"></textarea>
          </div>
        </div>

        <div class="color-highlight green">
          <h3>🔒 <?php echo $currentLang === 'fr' ? 'Protection des données' : 'Data Protection'; ?></h3>
          <p>
            <?php echo $currentLang === 'fr' 
              ? 'Votre signalement est entièrement anonyme. Aucune information personnelle n\'est collectée et toutes les données sont chiffrées de bout en bout.' 
              : 'Your report is completely anonymous. No personal information is collected and all data is end-to-end encrypted.'; ?>
          </p>
        </div>

        <div class="checkbox-group">
          <input type="checkbox" class="form-checkbox" id="consentCheckbox" name="consent" required>
          <label class="checkbox-label" for="consentCheckbox">
            <?php if ($currentLang === 'fr'): ?>
              Je certifie que les informations fournies sont exactes à ma connaissance et j'accepte que ce signalement soit traité de manière anonyme conformément à la <a href="confidentialite.php">politique de confidentialité</a>.
            <?php else: ?>
              I certify that the information provided is accurate to my knowledge and I accept that this report be processed anonymously in accordance with the <a href="confidentialite.php">privacy policy</a>.
            <?php endif; ?>
          </label>
        </div>

        <button type="submit" class="submit-btn" id="submitBtn">
          <?php echo $currentLang === 'fr' ? 'Soumettre l\'alerte' : 'Submit Alert'; ?>
        </button>
      </form>
    <?php endif; ?>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-brand">
          <img src="image/logoofficielle.png" alt="Alerte Sénégal" class="footer-logo">
          <div>
            <div style="color: white; font-weight: 600; margin-bottom: 0.5rem;">Alerte Sénégal</div>
            <div style="color: var(--muted); font-size: 0.875rem;">
              <?php echo $currentLang === 'fr' ? 'Plateforme officielle de signalement éthique' : 'Official ethical reporting platform'; ?>
            </div>
          </div>
        </div>
        
        <div class="footer-links">
          <div class="footer-column">
            <h4><?php echo $currentLang === 'fr' ? 'Navigation' : 'Navigation'; ?></h4>
            <a href="index.php"><?php echo $currentLang === 'fr' ? 'Accueil' : 'Home'; ?></a>
            <a href="soumettre.php"><?php echo $currentLang === 'fr' ? 'Soumettre une alerte' : 'Submit alert'; ?></a>
            <a href="suivi.php"><?php echo $currentLang === 'fr' ? 'Suivre une alerte' : 'Track alert'; ?></a>
          </div>
          
          <div class="footer-column">
            <h4><?php echo $currentLang === 'fr' ? 'À propos' : 'About'; ?></h4>
            <a href="apropos.php"><?php echo $currentLang === 'fr' ? 'Notre mission' : 'Our mission'; ?></a>
            <a href="confidentialite.php"><?php echo $currentLang === 'fr' ? 'Confidentialité' : 'Privacy'; ?></a>
            <a href="mentions-legales.php"><?php echo $currentLang === 'fr' ? 'Mentions légales' : 'Legal notices'; ?></a>
          </div>
          
          <div class="footer-column">
            <h4><?php echo $currentLang === 'fr' ? 'Contact' : 'Contact'; ?></h4>
            <a href="contact.php"><?php echo $currentLang === 'fr' ? 'Nous contacter' : 'Contact us'; ?></a>
            <a href="faq.php">FAQ</a>
            <a href="support.php"><?php echo $currentLang === 'fr' ? 'Support' : 'Support'; ?></a>
          </div>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p>© 2025 Alerte Sénégal - <?php echo $currentLang === 'fr' 
          ? 'Conforme à la loi sénégalaise n° 2008-12 sur la protection des données personnelles' 
          : 'Compliant with Senegalese law n° 2008-12 on personal data protection'; ?></p>
      </div>
    </div>
  </footer>

  <script>
    // Gestion du menu mobile
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    
    if (menuToggle && navLinks) {
      menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
      });
    }

    // Gestion du changement de langue
    const langButtons = document.querySelectorAll('.lang-btn');
    
    langButtons.forEach(button => {
      button.addEventListener('click', () => {
        const lang = button.getAttribute('data-lang');
        const form = document.getElementById('alertForm');
        
        if (form) {
          // Mettre à jour le champ caché de langue
          const langInput = form.querySelector('input[name="lang"]');
          if (langInput) {
            langInput.value = lang;
          }
          
          // Soumettre le formulaire
          form.submit();
        }
      });
    });

    // Gestion de l'upload de fichiers
    const fileUpload = document.getElementById('fileUpload');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');
    
    if (fileUpload && fileInput && fileList) {
      const files = [];
      
      fileUpload.addEventListener('click', () => fileInput.click());
      
      fileUpload.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileUpload.style.borderColor = 'var(--accent)';
        fileUpload.style.background = 'rgba(68, 28, 138, 0.1)';
      });
      
      fileUpload.addEventListener('dragleave', () => {
        fileUpload.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        fileUpload.style.background = 'rgba(59, 130, 246, 0.05)';
      });
      
      fileUpload.addEventListener('drop', (e) => {
        e.preventDefault();
        fileUpload.style.borderColor = 'rgba(255, 255, 255, 0.2)';
        fileUpload.style.background = 'rgba(59, 130, 246, 0.05)';
        
        if (e.dataTransfer.files.length > 0) {
          handleFiles(e.dataTransfer.files);
        }
      });

      fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
          handleFiles(e.target.files);
        }
      });

      function handleFiles(newFiles) {
        for (let file of newFiles) {
          if (file.size > 10 * 1024 * 1024) {
            alert(`<?php echo $currentLang === 'fr' 
              ? 'Le fichier "' : 'The file "'; ?>${file.name}<?php echo $currentLang === 'fr' 
              ? '" dépasse la taille maximale de 10MB' : '" exceeds the maximum size of 10MB'; ?>`);
            continue;
          }
          
          const allowedTypes = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'mp4', 'mov', 'avi'];
          const fileExtension = file.name.split('.').pop().toLowerCase();
          
          if (!allowedTypes.includes(fileExtension)) {
            alert(`<?php echo $currentLang === 'fr' 
              ? 'Le format du fichier "' : 'The file format "'; ?>${file.name}<?php echo $currentLang === 'fr' 
              ? '" n\'est pas supporté' : '" is not supported'; ?>`);
            continue;
          }
          
          files.push(file);
          renderFileList();
        }
        fileInput.value = '';
      }

      function renderFileList() {
        fileList.innerHTML = '';
        files.forEach((file, index) => {
          const fileItem = document.createElement('div');
          fileItem.className = 'file-item';
          fileItem.innerHTML = `
            <span>${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)</span>
            <button type="button" class="file-remove" data-index="${index}">✕</button>
          `;
          fileList.appendChild(fileItem);
        });

        fileList.querySelectorAll('.file-remove').forEach(button => {
          button.addEventListener('click', (e) => {
            const index = parseInt(e.target.getAttribute('data-index'));
            files.splice(index, 1);
            renderFileList();
          });
        });
      }
    }

    // Empêcher la soumission multiple du formulaire
    const form = document.getElementById('alertForm');
    if (form) {
      form.addEventListener('submit', function() {
        const submitBtn = this.querySelector('#submitBtn');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = '<?php echo $currentLang === 'fr' 
            ? 'Traitement en cours...' : 'Processing...'; ?>';
        }
      });
    }
  </script>
</body>
</html>